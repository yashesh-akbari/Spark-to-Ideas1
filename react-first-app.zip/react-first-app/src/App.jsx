// import React from 'react';
// // import home from './componet/home';
// import About from './componet/about';
// import Home from './componet/home';
// import Contact from './componet/contact';
// // import contact from './componet/contact';
// import Event from './componet/event';
// import Event1 from './componet/event1';

// function App() {
//   return (
//     <main>
//       <section>
//        <Home/>
//       </section>
//       <section style={{
//           backgroundImage: `url(${aboutbgimage})`,
//           backgroundSize: 'cover',
//           backgroundPosition: 'center',
//           display: 'flex',
//           justifyContent: 'center',
//           alignItems: 'center',
//           color: 'black',
        
//         }}>
//        <About/>
//       </section>
//       <section style={{
//           backgroundImage: `url(${contactbgimage})`,
//           backgroundSize: 'cover',
//           backgroundPosition: 'center',
//           display: 'flex',
//           justifyContent: 'center',
//           alignItems: 'center',
//           color: 'black'
//         }}>
//        <Event/>
//       </section>
//       <section style={{
//           backgroundImage: `url(${contactbgimage})`,
//           backgroundSize: 'cover',
//           backgroundPosition: 'center',
//           display: 'flex',
//           justifyContent: 'center',
//           alignItems: 'center',
//           color: 'black'
//         }}>
//        <Event1/>
//       </section>
//       <section style={{
//           backgroundImage: `url(${backgroundImage2})`,
//           backgroundSize: 'cover',
//           backgroundPosition: 'center',
//           display: 'flex',
//           justifyContent: 'center',
//           alignItems: 'center',
//           color: 'black',
        
//         }}>
//        <Contact/>
//       </section>
//     </main>
//   )
// }

// export default App;
// const backgroundImage = 'party.jpeg';
// const backgroundImage1= 'background.jpeg'; 
// const backgroundImage2 = 'button_background.jpeg';
// const backgroundImage3 = 'background2.jpeg'
// const contactbgimage = 'contact.jpeg'
// const aboutbgimage = 'aboutus.jpeg'

import React, { useState } from 'react';
import About from './componet/about';
import Home from './componet/home';
import Contact from './componet/contact';
import Event from './componet/event';
import Event1 from './componet/event1';
import Signin from './componet/signin';

function App() {
  const [currentSection, setCurrentSection] = useState('home');

  const handleSectionChange = (section) => {
    setCurrentSection(section);
  };

  return (
    <main>
      <pre style={{
          backgroundImage: `url(${backgroundImage1})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          textTransform: 'uppercase',
          //justifyContent: 'center',
          //alignItems: 'center',
          color: '#fff',
          margin: 0,
          padding: 0,
        }}>
      <nav>
      <img src="/logo.png" alt="Harmoni Logo" height={40} width={70} /> 
            <a href="#" onClick={() => handleSectionChange('home')}>                                      Home               </a>
         
          
            <a href="#" onClick={() => handleSectionChange('about')}>About               </a>
         
            <a href="#" onClick={() => handleSectionChange('event','event1')}>Event               </a>
         
            <a href="#" onClick={() => handleSectionChange('contact')}>Contact                                                </a>

            <button className="signin" onClick={() => handleSectionChange('signin')} style={{backgroundColor : 'red',
          color: 'white' ,
          justifyContent: 'center',
          alignItems: 'center',}} ><svg xmlns="http://www.w3.org/2000/svg" height="16px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg>Sign In</button>
      </nav>
      </pre>
      {currentSection === 'home' && (
        <section>
          <Home />
        </section>
      )}
      {currentSection === 'about' && (
        <section style={{
          backgroundImage: `url(${aboutbgimage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          color: 'black',
        }}>
          <About />
        </section>
      )}
      {currentSection === 'event' && (
        <section style={{
          backgroundImage: `url(${contactbgimage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          color: 'black',
        }}>
          <Event />
        </section>
      )}
      {currentSection === 'event1' && (
        <section style={{
          backgroundImage: `url(${contactbgimage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          color: 'black',
        }}>
          <Event1 />
        </section>
      )}
      {currentSection === 'signin' && (
        <section style={{
          backgroundImage: `url(${backgroundImage3})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          color: 'black',
        }}>
          <Signin />
        </section>
      )}
      {currentSection === 'contact' && (
        <section style={{
          backgroundImage: `url(${backgroundImage2})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          color: 'black',
        }}>
          <Contact />
        </section>
      )}
    </main>
  );
}

export default App;

const backgroundImage = 'party.jpeg';
const backgroundImage1 = 'background.jpeg';
const backgroundImage2 = 'button_background.jpeg';
const backgroundImage3 = 'background2.jpeg';
const contactbgimage = 'contact.jpeg';
const aboutbgimage = 'aboutus.jpeg';