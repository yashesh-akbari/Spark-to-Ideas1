import React from 'react';
// import home from './componet/home';
import about from './componet/about';
// import contact from './componet/contact';
// import event from './componet/event';
// import gallery from './componet/gallery';

function App() {
  return (
    <div className="container">
      <header className="header" style={{
          backgroundImage: `url(${backgroundImage1})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          textTransform: 'uppercase',
          //justifyContent: 'center',
          //alignItems: 'center',
          color: '#fff',
          margin: 0,
          padding: 0,
        }}>
        <div className="logo">
          <pre><nav>
          <img src="/logo.png" alt="Harmoni Logo" height={40} width={70} /> <a href="#">                             Home         </a> <a href="#">     About        </a><a href="#">      Events          </a><a href="#">      Gallery         </a><a href="#">     Contact            </a>                 <button className="signin" style={{backgroundColor : 'red',
          color: 'white' ,
          justifyContent: 'center',
          alignItems: 'center',}} ><svg xmlns="http://www.w3.org/2000/svg" height="16px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg>Sign In  </button>      </nav>
        </pre>
        </div>
      </header>

      <main className="main">
        <section className="hero" style={{
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          height: '100vh',
          display: 'flex',
          justifyContent: 'left',
          // justifyContent: 'left',
          // alignItems: 'center',
          color: 'Yellow',
        }}>
          <pre>
          <h1 style={{color: 'aqua',textTransform: 'capitalize',margin:20,padding: 2,textShadow: 100,}} className='heading'> One Stop Event 
          </h1>  
          <h1 style={{color: 'aqua',textTransform: 'capitalize',margin:20,padding: 2}}> Planner</h1>
          <p> </p>
          <p style={{margin:10}}>      Yet bed any for travelling assistance indulgence unpleasing.</p>
             <p style={{margin:10,}}>      Not thoughts all exercise blessing. </p><p style={{margin:10,}}>      Indulgence way everything joy alteration boisterous the attachment.</p>
          <p style={{margin:10,}}>      Party we years to order allow asked of. Every event should be Perfect</p>
          <div className="form">
            <input type="email" className='emailbox' placeholder="Your Email Address" style={{margin:50,paddingBlock: 4,
            paddingInline: 4,}} />      
               <button style={{backgroundColor:'red'}}>Get Started</button>
          </div>

         <h3 style={{color: 'Red',margin:15,}}>      1,600 people requested access a visit in last 24 hours</h3>
          </pre>
        </section>
      </main>

      <footer style={{
          backgroundImage: `url(${backgroundImage2})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          justifyContent: 'center',
          // alignItems: 'center',
          color: 'black'
        }}>    <pre>   linkedin.com/in/yashesh-akbari </pre>
        <p> </p>
        </footer>
    </div>
  );
}

export default App;
const backgroundImage = 'party.jpeg';
const backgroundImage1= 'background.jpeg'; 
const backgroundImage2 = 'button_background.jpeg';
const backgroundImage3 = 'background2.jpeg'