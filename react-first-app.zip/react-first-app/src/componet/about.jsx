import React from 'react';

const About = () => {
  return (
    <center>
    <div className="about-page">
      <h1>About Us</h1>
      <p>Welcome to EventMaster, your one-stop-shop for all your event management needs!</p>
      <section className="about-section">
        <h2>Our Mission</h2>
        <p>At EventMaster, our mission is to provide a seamless and stress-free event planning experience for our clients. We believe that every event is unique and deserves to be memorable, which is why we offer a range of services tailored to meet your specific needs.</p>
      </section>
      <section className="about-section">
        <h2>Our Team</h2>
            <img src="team member 1.jpeg" alt="Team Member 1" />
            <h3>John Doe</h3>
            <p>Founder & CEO</p>
            <img src="team member 2.jpeg" alt="Team Member 2" />
            <h3>Jane Smith</h3>
            <p>Event Coordinator</p>
            <img src="team member 3.jpeg" alt="Team Member 3" />
            <h3>Bob Johnson</h3>
            <p>Technical Lead</p>
      </section>
      <section className="about-section">
        <h2>Our Services</h2>
        Event Conceptualization
        <br />
        Venue Selection
        <br />
        Catering and Beverage Management
            <br />
            Audio-Visual and Technical Support
          <br />
          Event Marketing and Promotion
      </section>
      <section className="about-section">
        <h2>Testimonials</h2>
        <blockquote>
          "EventMaster exceeded our expectations in every way. Their attention to detail and professionalism made our event a huge success!" - Emily R.
        </blockquote>
        <blockquote>
          "I was blown away by the level of service provided by EventMaster. They truly went above and beyond to make our event unforgettable!" - David K.
        </blockquote>
      </section>
    </div>
    </center>
  );
};

export default About;