import React from 'react'

export default function about() {
  return (
    <div>about</div>
  )
}
