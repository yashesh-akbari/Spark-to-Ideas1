import React from 'react';

function Home() {
  return (
    <div className="container">

      <main className="main">
        <section className="hero" style={{
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          height: '100vh',
          display: 'flex',
          justifyContent: 'left',
          // justifyContent: 'left',
          // alignItems: 'center',
          color: 'Yellow',
        }}>
          <pre>
          <h1 style={{color: 'aqua',textTransform: 'capitalize',margin:20,padding: 2,textShadow: 100,}} className='heading'> One Stop Event 
          </h1>  
          <h1 style={{color: 'aqua',textTransform: 'capitalize',margin:20,padding: 2}}> Planner</h1>
          <p> </p>
          <p style={{margin:10}}>      Yet bed any for travelling assistance indulgence unpleasing.</p>
             <p style={{margin:10,}}>      Not thoughts all exercise blessing. </p><p style={{margin:10,}}>      Indulgence way everything joy alteration boisterous the attachment.</p>
          <p style={{margin:10,}}>      Party we years to order allow asked of. Every event should be Perfect</p>
          <div className="form">
            <input type="email" className='emailbox' placeholder="Your Email Address" style={{margin:50,paddingBlock: 4,
            paddingInline: 4,}} />      
               <button style={{backgroundColor:'red'}}>Get Started</button>
          </div>

         <h3 style={{color: 'Red',margin:15,}}>      1,600 people requested access a visit in last 24 hours</h3>
          </pre>
        </section>
        </main>
        

      <footer style={{
          backgroundImage: `url(${backgroundImage2})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          justifyContent: 'center',
          // alignItems: 'center',
          color: 'black'
        }}>    <pre>   linkedin.com/in/yashesh-akbari </pre>
        <p> </p>
        </footer>
        </div>
  );
}

export default Home;
const backgroundImage = 'party.jpeg';
const backgroundImage1= 'background.jpeg'; 
const backgroundImage2 = 'button_background.jpeg';
const backgroundImage3 = 'background2.jpeg'
const contactbgimage = 'contact.jpeg'
