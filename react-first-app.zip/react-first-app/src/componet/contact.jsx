import React, { useState } from 'react';

function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [country, setCountry] = useState('');
  const [phone, setPhone] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);

    // Here you can handle the form submission
    // For example, you can send the data to a backend server
    // Or you can simply display the data to the user
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Country:', country);
    console.log('Phone:', phone);
  };

  return (
    <main>
    <div className="contact-form">
      <h1 style={{textAlign:"center"}}>Contact Us</h1>
      <br />
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <br />
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <br />
        <div className="form-group">
          <label htmlFor="country">Country:</label>
          <input
            type="text"
            id="country"
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            required
          />
        </div>
        <br />
        <div className="form-group">
          <label htmlFor="phone">Phone Number:</label>
          <input
            type="tel"
            id="phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
          />
        </div>
        <br />
        <button type="submit">Submit</button>
      </form>
      {submitted && (
        <div className="message">
          <b><h2>Thank you for your message!</h2>
          <p>We will get back to you as soon as possible.</p></b>
        </div>
      )}
    </div>
    <section className="about-section" style={{textAlign:"center"}}>
        <h2>Get in Touch</h2>
        <p>Have a question or want to learn more about our services? Contact us today!</p>
          <a href="mailto:info@eventmaster.com">info@eventmaster.com</a>
          <br />
          <a href="tel:+1-555-123-4567">+1-555-123-4567</a>
          <br />
          <a href="https://www.eventmaster.com/contact">Contact Form</a>
      </section>
    </main>
  );
}

export default Contact;