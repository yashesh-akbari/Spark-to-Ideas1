import React, { useState } from 'react';
import App from '../App';

function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle login logic here
  };

  return (
    <form onSubmit={() => handleSectionChange('home')}>
      <br />
      Email: <input style={{color:"yellow"}}
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Enter email"
      />
      <br />
      Password: <input
        type="password" style={{color:"yellow"}}
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Enter password"
      />
      <br />
      <br />
      <button type="submit" style={{textAlign:"center"}}>Login</button>
      <br />
      <p style={{color:"red", textAlign:"center"}}>OR</p>
      <br />
    </form>
  );
}

function SignupForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle signup logic here
  };

  return (
    <form onSubmit={() => handleSectionChange('home')}>
      Name: <input
        type="text"
        value={name} style={{color:"yellow"}}
        onChange={(e) => setName(e.target.value)}
        placeholder="Enter name"
      />
      <br />
      Email: <input
        type="email" style={{color:"yellow"}}
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Enter email"
      />
      <br />
      Password: <input
        type="password" style={{color:"yellow"}}
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Enter password"
      />
      <br />
      Confirm Password<input
        type="password" style={{color:"yellow"}}
        value={confirmPassword}
        onChange={(e) => setConfirmPassword(e.target.value)}
        placeholder="Confirm password"
      />
      <br />
      <br />
      <button type="submit">Sign Up</button>
    </form>
  );
}

function Signin() {
  return (
    <div>
      <LoginForm />
      <SignupForm />
    </div>
  );
}

export default Signin;
const aboutbgimage = 'aboutus.jpeg';