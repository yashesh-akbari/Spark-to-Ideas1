import React from 'react';

function Event1(){
  return (
    <div>
      <div style={{display: 'flex', justifyContent: 'pace-between'}}>
        <div>
        <h3><label htmlFor="Party" style={{marginLeft: '90px'}}>Party</label>
          <br /></h3>
          <img src="Party1.jpeg" alt="Party imgae" style={{width: '80%', height: 'auto', marginRight: '0px'}}/>
          <p>A night of dancing and celebration</p>
          <button style={{marginLeft: '50px'}}>Learn More</button>
        </div>
        <div>
        <h3><label htmlFor="navratri" style={{marginLeft: '175px'}}>Navratri</label></h3>
          <img src="navratri.jpeg" alt="navratri image" style={{width: '50%', height: 'auto',marginLeft: '120px'}}/>
          <p>A nine-night festival celebrating the victory of good over evil</p>
          <button style={{marginLeft: '175px'}}>Learn More</button>
        </div>
        <div>
        <h3><label htmlFor="Standup Comedy" style={{marginLeft: '200px'}}>Standup Comedy</label></h3>
          <img src="StandupComedy.jpeg" alt="StandupComedy image" style={{width: '50%', height: 'auto', marginLeft: '150px'}}/> 
          <p style={{marginLeft: '115px'}}>'An evening of laughs and entertainment.'</p>
          <button style={{marginLeft: '200px'}}>Learn More</button>
        </div>
      </div>
    </div>
  );
}

export default Event1;