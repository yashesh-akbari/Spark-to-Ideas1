import React from 'react'

export default function gallery() {
  return (
    <div>gallery</div>
  )
}
