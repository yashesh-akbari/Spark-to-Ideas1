import React from 'react'

export default function contact() {
  return (
    <div>contact</div>
  )
}
