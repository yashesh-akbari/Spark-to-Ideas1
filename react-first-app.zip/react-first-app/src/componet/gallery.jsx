import React, { useState, useEffect } from 'react';
import { Grid, Image, Header, Button, Icon } from 'semantic-ui-react';
import axios from 'axios';

const Gallery = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('https://my-api.com/events')
      .then(response => {
        setEvents(response.data);
        setLoading(false);
      })
      .catch(error => console.error(error));
  }, []);

  const handleDeleteEvent = (eventId) => {
    axios.delete(`https://my-api.com/events/${eventId}`)
      .then(response => {
        setEvents(events.filter(event => event.id !== eventId));
      })
      .catch(error => console.error(error));
  };

  return (
    <div>
      <Header as="h1">Event Gallery</Header>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <Grid columns={3} stackable>
          {events.map((event) => (
            <Grid.Column key={event.id}>
              <Image src={event.image} size="medium" />
              <Header as="h3">{event.name}</Header>
              <p>{event.description}</p>
              <Button color="red" onClick={() => handleDeleteEvent(event.id)}>
                <Icon name="trash" /> Delete
              </Button>
            </Grid.Column>
          ))}
        </Grid>
      )}
      <Button primary floated="right" as="a" href="/create-event">
        <Icon name="plus" /> Create New Event
      </Button>
    </div>
  );
};

export default Gallery;