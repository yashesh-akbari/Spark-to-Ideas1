/* const arr = [
  { name: "parth", rollno: 1, height: 5, status: "good" },
  { name: "jay", rollno: 2, height: 5, status: "good" },
  { name: "kavil", rollno: 3, height: 5, status: "good" },
  { name: "raj", rollno: 4, height: 5, status: "good" },
  { name: "ejjd", rollno: 5, height: 5, status: "good" },
]; */

const arr = [
  { name: "parth", rollno: 1, height: 5, status: "good" },
  { name: "jay", rollno: 2, height: 5, status: "good" },
  { name: "kavil", rollno: 3, height: 5, status: "good" },
  { name: "raj", rollno: 4, height: 5, status: "good" },
  { name: "ejjd", rollno: 5, height: 5, status: "good" },
];

const newArr = arr.map((obj) => {
  if (obj.rollno % 2 === 0) {
    obj.status = "bad";
  }
  return obj;
});

console.log(newArr);